# RBDS Diagnostic Log Analysis Guide

## Files in This Directory

### Basic Logs
- **rbds-basic.log** - Core RBDS activity (60 seconds)
- **rbds-detailed.log** - M&M timing, Costas, bit stats (90 seconds)
- **rbds-sync-events.log** - Presync and sync attempts (60 seconds)
- **rbds-full-context.log** - Complete logs with context (30 seconds)

### Configuration
- **redis-config.log** - RBDS-related Redis keys
- **audio-config.log** - Audio pipeline configuration
- **radio-config.log** - Radio receiver settings
- **signal-strength.log** - Current signal quality metrics

### Service Status
- **service-status.log** - Service health and status
- **service-journal-errors.log** - Recent errors
- **system-info.txt** - System specifications

## What to Look For

### 1. Syndrome Analysis (rbds-detailed.log)
Search for: `RBDS sync search: bit_counter=`

**Questions:**
- Are syndrome values consistently wrong by similar amounts?
- Do you see syndrome values like 775, 16, 906, 524, etc.?
- Are they always 4-7 bits different from targets [383, 14, 303, 663, 748]?

### 2. M&M Timing (rbds-detailed.log)
Search for: `RBDS M&M:`

**Questions:**
- Is the symbol count consistent? (e.g., "374 samples -> 24 symbols")
- Does it vary by more than ±2 symbols between calls?
- Are there timing slips or jumps?

### 3. Bit Statistics (rbds-detailed.log)
Search for: `RBDS bits:`

**Questions:**
- What percentage of bits are ones? (Should be close to 50%)
- Is it consistently around 33% or 66%? (Indicates possible inversion)
- Does the percentage vary wildly? (Indicates noise)

### 4. Costas Loop (rbds-detailed.log)
Search for: `RBDS Costas:`

**Questions:**
- Is frequency offset stable? (Should be < 5 Hz)
- Does frequency drift over time?
- Does phase wrap around frequently? (Could indicate tracking issues)

### 5. Presync Activity (rbds-sync-events.log)
Search for: `RBDS presync:`

**Questions:**
- Do you see "first block type X" messages?
- Are they for exact matches or fuzzy matches?
- If fuzzy, how many bit errors? (1-2 is OK, >2 is concerning)
- Do you see spacing mismatches?

### 6. Sync Achievement (rbds-sync-events.log)
Search for: `RBDS SYNCHRONIZED`

**Questions:**
- Does sync ever happen?
- If yes, does it stay synced or lose sync quickly?
- If no, why? (Check presync spacing mismatches)

### 7. Signal Quality (signal-strength.log)
**Questions:**
- What is the signal strength? (Should be > 60 dBμV at 8 miles)
- What is the SNR? (Should be > 40 dB for FM)
- Are values stable or fluctuating?

## Analysis Workflow

1. **Check if RBDS is enabled**
   - Look in redis-config.log for `rbds:enabled` = true
   
2. **Verify signal quality**
   - Check signal-strength.log for strong signal (8 miles = excellent)
   
3. **Examine syndrome patterns**
   - Open rbds-detailed.log
   - Find syndrome values
   - Calculate how many bits differ from targets
   
4. **Check M&M timing stability**
   - Look for "RBDS M&M:" lines
   - Verify symbol counts are consistent
   
5. **Analyze bit distribution**
   - Find "RBDS bits:" lines
   - Check if % ones is around 50%
   
6. **Review presync attempts**
   - Open rbds-sync-events.log
   - Count how many presync attempts
   - Check if spacing validation ever succeeds

## Common Issues and Signatures

### Issue: Perfect signal but no syndrome matches
**Signature:**
- Strong signal (> 60 dBμV)
- Syndromes consistently 4-7 bits off
- M&M producing symbols
- Costas tracking

**Likely Cause:** Bit corruption in M&M or differential decoding

### Issue: Presync finds blocks but spacing always wrong
**Signature:**
- See "presync: first block type X"
- See "spacing mismatch (expected 26, got XXX)"
- Never see "SYNCHRONIZED"

**Likely Cause:** False positive syndrome matches (noise) or timing drift

### Issue: Sync achieved but immediately lost
**Signature:**
- See "SYNCHRONIZED at bit X"
- See "SYNC LOST" shortly after
- See many "block FAILED CRC"

**Likely Cause:** Weak signal or phase slips in Costas loop

### Issue: No activity at all
**Signature:**
- No "RBDS" log lines
- No M&M, Costas, or bits logs

**Likely Cause:** RBDS not enabled, or station doesn't broadcast RBDS

## Next Steps

Based on what you find, provide:

1. **Syndrome pattern** - List 10 consecutive syndrome values from logs
2. **M&M behavior** - Show 5 consecutive M&M timing lines
3. **Bit statistics** - Report % ones over 10 measurements
4. **Presync results** - Did it find any blocks? What spacing errors?
5. **Signal strength** - What are the actual dBμV and SNR values?

With this information, the exact failure point can be identified.
